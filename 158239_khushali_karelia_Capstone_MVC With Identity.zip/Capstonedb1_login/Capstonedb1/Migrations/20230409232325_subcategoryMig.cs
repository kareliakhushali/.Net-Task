﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Capstonedb1.Migrations
{
    public partial class subcategoryMig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
